// وسيط للتحقق من تسجيل الدخول، ويجعل بيانات المستخدم متاحة في كل الصفحات
const db = require('../db');

// يعمل على كل الطلبات: يحمّل بيانات المستخدم من الجلسة إن وجدت
function loadUser(req, res, next) {
  if (req.session && req.session.userId) {
    const user = db.prepare('SELECT id, name, phone, state FROM users WHERE id = ?').get(req.session.userId);
    req.user = user || null;
  } else {
    req.user = null;
  }
  res.locals.currentUser = req.user; // متاح تلقائيًا داخل EJS
  next();
}

// يحمي المسارات التي تتطلب تسجيل دخول
function requireAuth(req, res, next) {
  if (!req.user) {
    req.session.redirectTo = req.originalUrl;
    return res.redirect('/login');
  }
  next();
}

module.exports = { loadUser, requireAuth };

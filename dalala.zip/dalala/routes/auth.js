const express = require('express');
const router = express.Router();
const db = require('../db');

// عرض صفحة تسجيل الدخول
router.get('/login', (req, res) => {
  if (req.user) return res.redirect('/');
  const states = db.prepare('SELECT name FROM states ORDER BY sort_order').all();
  res.render('login', { title: 'تسجيل الدخول', states, error: null });
});

// معالجة تسجيل الدخول: تسجيل دخول بسيط بالاسم ورقم الجوال (بدون كلمة سر)
// إذا كان الرقم مسجّل من قبل، يتم تسجيل الدخول لنفس الحساب
router.post('/login', (req, res) => {
  const { name, phone, state } = req.body;
  const states = db.prepare('SELECT name FROM states ORDER BY sort_order').all();

  const cleanPhone = (phone || '').trim().replace(/[^\d+]/g, '');
  const cleanName = (name || '').trim();

  if (!cleanName || cleanName.length < 2) {
    return res.render('login', { title: 'تسجيل الدخول', states, error: 'الرجاء إدخال اسم صحيح.' });
  }
  if (!/^\+?\d{8,14}$/.test(cleanPhone)) {
    return res.render('login', { title: 'تسجيل الدخول', states, error: 'رقم الجوال غير صحيح. تأكد من كتابته بشكل صحيح.' });
  }

  let user = db.prepare('SELECT * FROM users WHERE phone = ?').get(cleanPhone);
  if (!user) {
    const result = db.prepare('INSERT INTO users (name, phone, state) VALUES (?, ?, ?)').run(cleanName, cleanPhone, state || null);
    user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
  } else if (state && state !== user.state) {
    db.prepare('UPDATE users SET state = ? WHERE id = ?').run(state, user.id);
  }

  req.session.userId = user.id;
  const redirectTo = req.session.redirectTo || '/';
  delete req.session.redirectTo;
  res.redirect(redirectTo);
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

module.exports = router;

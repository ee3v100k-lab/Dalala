const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');

function timeAgo(dateStr) {
  const diffMs = Date.now() - new Date(dateStr.replace(' ', 'T') + 'Z').getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'الآن';
  if (mins < 60) return `قبل ${mins} دقيقة`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `قبل ${hours} ساعة`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `قبل ${days} يوم`;
  const months = Math.floor(days / 30);
  return `قبل ${months} شهر`;
}

function formatPrice(ad) {
  if (ad.price === null || ad.price === undefined) return 'السعر عند الاتفاق';
  const n = Number(ad.price).toLocaleString('ar-SD');
  return `${n} ${ad.currency === 'SDG' ? 'ج.س' : ad.currency}` + (ad.price_negotiable ? ' (قابل للتفاوض)' : '');
}

function attachHelpers(ads) {
  return ads.map(a => ({ ...a, timeAgoText: timeAgo(a.created_at), priceText: formatPrice(a) }));
}

// ===================== الصفحة الرئيسية / البحث والفلترة =====================
router.get('/', (req, res) => {
  const categories = db.prepare('SELECT * FROM categories ORDER BY sort_order').all();
  const states = db.prepare('SELECT * FROM states ORDER BY sort_order').all();

  const { q, category, state } = req.query;
  let sql = `
    SELECT ads.*, categories.name AS category_name,
      (SELECT filename FROM ad_images WHERE ad_id = ads.id ORDER BY sort_order LIMIT 1) AS thumb
    FROM ads
    JOIN categories ON categories.id = ads.category_id
    WHERE ads.status = 'active'
  `;
  const params = [];
  if (q && q.trim()) {
    sql += ' AND (ads.title LIKE ? OR ads.description LIKE ?)';
    params.push(`%${q.trim()}%`, `%${q.trim()}%`);
  }
  if (category) {
    sql += ' AND categories.name = ?';
    params.push(category);
  }
  if (state) {
    sql += ' AND ads.state = ?';
    params.push(state);
  }
  sql += ' ORDER BY ads.created_at DESC LIMIT 48';

  const ads = attachHelpers(db.prepare(sql).all(...params));

  res.render('index', {
    title: 'دلالة | سوق السودان',
    categories, states, ads,
    query: { q: q || '', category: category || '', state: state || '' },
  });
});

// ===================== نشر إعلان جديد =====================
router.get('/ads/new', requireAuth, (req, res) => {
  const categories = db.prepare('SELECT * FROM categories ORDER BY sort_order').all();
  const states = db.prepare('SELECT * FROM states ORDER BY sort_order').all();
  res.render('post-ad', { title: 'أضف إعلانك | دلالة', categories, states, error: null, form: {} });
});

router.post('/ads/new', requireAuth, (req, res, next) => {
  upload.array('images', 6)(req, res, (err) => {
    if (err) {
      const categories = db.prepare('SELECT * FROM categories ORDER BY sort_order').all();
      const states = db.prepare('SELECT * FROM states ORDER BY sort_order').all();
      return res.render('post-ad', { title: 'أضف إعلانك | دلالة', categories, states, error: err.message, form: req.body });
    }
    next();
  });
}, (req, res) => {
  const categories = db.prepare('SELECT * FROM categories ORDER BY sort_order').all();
  const states = db.prepare('SELECT * FROM states ORDER BY sort_order').all();
  const { title, description, price, negotiable, category_id, state, city } = req.body;

  const cleanupUploaded = () => {
    (req.files || []).forEach(f => fs.unlink(path.join(__dirname, '..', 'public', 'uploads', f.filename), () => {}));
  };

  if (!title || title.trim().length < 4) {
    cleanupUploaded();
    return res.render('post-ad', { title: 'أضف إعلانك | دلالة', categories, states, error: 'عنوان الإعلان قصير جدًا، اكتب عنوان واضح.', form: req.body });
  }
  if (!category_id || !state) {
    cleanupUploaded();
    return res.render('post-ad', { title: 'أضف إعلانك | دلالة', categories, states, error: 'الرجاء اختيار القسم والولاية.', form: req.body });
  }

  const priceVal = price && price.trim() !== '' ? Number(price) : null;

  const result = db.prepare(`
    INSERT INTO ads (user_id, category_id, title, description, price, price_negotiable, currency, state, city)
    VALUES (?, ?, ?, ?, ?, ?, 'SDG', ?, ?)
  `).run(req.user.id, category_id, title.trim(), (description || '').trim(), priceVal, negotiable ? 1 : 0, state, city || null);

  const adId = result.lastInsertRowid;

  const files = req.files || [];
  const insertImg = db.prepare('INSERT INTO ad_images (ad_id, filename, sort_order) VALUES (?, ?, ?)');
  files.forEach((f, i) => insertImg.run(adId, f.filename, i));

  res.redirect(`/ads/${adId}`);
});

// ===================== إعلاناتي =====================
router.get('/my-ads', requireAuth, (req, res) => {
  const ads = attachHelpers(db.prepare(`
    SELECT ads.*, categories.name AS category_name,
      (SELECT filename FROM ad_images WHERE ad_id = ads.id ORDER BY sort_order LIMIT 1) AS thumb
    FROM ads JOIN categories ON categories.id = ads.category_id
    WHERE ads.user_id = ? ORDER BY ads.created_at DESC
  `).all(req.user.id));
  res.render('my-ads', { title: 'إعلاناتي | دلالة', ads });
});

router.post('/ads/:id/status', requireAuth, (req, res) => {
  const ad = db.prepare('SELECT * FROM ads WHERE id = ?').get(req.params.id);
  if (!ad || ad.user_id !== req.user.id) return res.status(403).send('غير مصرح');
  const status = ['active', 'sold', 'hidden'].includes(req.body.status) ? req.body.status : 'active';
  db.prepare("UPDATE ads SET status = ?, updated_at = datetime('now') WHERE id = ?").run(status, ad.id);
  res.redirect('/my-ads');
});

router.post('/ads/:id/delete', requireAuth, (req, res) => {
  const ad = db.prepare('SELECT * FROM ads WHERE id = ?').get(req.params.id);
  if (!ad || ad.user_id !== req.user.id) return res.status(403).send('غير مصرح');

  const images = db.prepare('SELECT filename FROM ad_images WHERE ad_id = ?').all(ad.id);
  images.forEach(img => {
    const p = path.join(__dirname, '..', 'public', 'uploads', img.filename);
    fs.unlink(p, () => {});
  });

  db.prepare('DELETE FROM ads WHERE id = ?').run(ad.id);
  res.redirect('/my-ads');
});

// ===================== تفاصيل الإعلان =====================
router.get('/ads/:id', (req, res) => {
  const ad = db.prepare(`
    SELECT ads.*, categories.name AS category_name
    FROM ads JOIN categories ON categories.id = ads.category_id
    WHERE ads.id = ?
  `).get(req.params.id);

  if (!ad) return res.status(404).render('404', { title: 'الإعلان غير موجود' });

  if (!req.user || req.user.id !== ad.user_id) {
    db.prepare('UPDATE ads SET views = views + 1 WHERE id = ?').run(ad.id);
    ad.views += 1;
  }

  const images = db.prepare('SELECT * FROM ad_images WHERE ad_id = ? ORDER BY sort_order').all(ad.id);
  const seller = db.prepare('SELECT id, name, phone, state, created_at FROM users WHERE id = ?').get(ad.user_id);
  const isFav = req.user
    ? !!db.prepare('SELECT 1 FROM favorites WHERE user_id = ? AND ad_id = ?').get(req.user.id, ad.id)
    : false;

  const [adWithHelpers] = attachHelpers([ad]);

  res.render('ad', {
    title: `${ad.title} | دلالة`,
    ad: adWithHelpers, images, seller, isFav,
  });
});

module.exports = router;

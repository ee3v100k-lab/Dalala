const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

// صندوق الوارد: كل المحادثات التي يشارك فيها المستخدم (كبائع أو مشتري)
router.get('/inbox', requireAuth, (req, res) => {
  const conversations = db.prepare(`
    SELECT c.*, ads.title AS ad_title, ads.id AS ad_id,
      (SELECT filename FROM ad_images WHERE ad_id = ads.id ORDER BY sort_order LIMIT 1) AS ad_thumb,
      buyer.name AS buyer_name, seller.name AS seller_name,
      (SELECT body FROM messages WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) AS last_message,
      (SELECT created_at FROM messages WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) AS last_message_at
    FROM conversations c
    JOIN ads ON ads.id = c.ad_id
    JOIN users buyer ON buyer.id = c.buyer_id
    JOIN users seller ON seller.id = c.seller_id
    WHERE c.buyer_id = ? OR c.seller_id = ?
    ORDER BY last_message_at DESC
  `).all(req.user.id, req.user.id);

  res.render('inbox', { title: 'المحادثات | دلالة', conversations, myId: req.user.id });
});

// بدء محادثة جديدة من صفحة الإعلان (المشتري يراسل البائع)
router.post('/ads/:id/message', requireAuth, (req, res) => {
  const ad = db.prepare('SELECT * FROM ads WHERE id = ?').get(req.params.id);
  if (!ad) return res.status(404).send('الإعلان غير موجود');
  if (ad.user_id === req.user.id) return res.redirect('/inbox');

  const body = (req.body.body || '').trim();
  if (!body) return res.redirect(`/ads/${ad.id}`);

  let conv = db.prepare('SELECT * FROM conversations WHERE ad_id = ? AND buyer_id = ?').get(ad.id, req.user.id);
  if (!conv) {
    const result = db.prepare('INSERT INTO conversations (ad_id, buyer_id, seller_id) VALUES (?, ?, ?)').run(ad.id, req.user.id, ad.user_id);
    conv = { id: result.lastInsertRowid };
  }

  db.prepare('INSERT INTO messages (conversation_id, sender_id, body) VALUES (?, ?, ?)').run(conv.id, req.user.id, body);

  res.redirect(`/chat/${conv.id}`);
});

// عرض محادثة واحدة
router.get('/chat/:id', requireAuth, (req, res) => {
  const conv = db.prepare(`
    SELECT c.*, ads.title AS ad_title, ads.id AS ad_id,
      buyer.name AS buyer_name, seller.name AS seller_name
    FROM conversations c
    JOIN ads ON ads.id = c.ad_id
    JOIN users buyer ON buyer.id = c.buyer_id
    JOIN users seller ON seller.id = c.seller_id
    WHERE c.id = ?
  `).get(req.params.id);

  if (!conv || (conv.buyer_id !== req.user.id && conv.seller_id !== req.user.id)) {
    return res.status(403).send('غير مصرح لك بعرض هذه المحادثة');
  }

  const messages = db.prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC').all(conv.id);
  db.prepare(`UPDATE messages SET read_at = datetime('now') WHERE conversation_id = ? AND sender_id != ? AND read_at IS NULL`)
    .run(conv.id, req.user.id);

  const otherName = conv.buyer_id === req.user.id ? conv.seller_name : conv.buyer_name;

  res.render('chat', { title: `محادثة مع ${otherName} | دلالة`, conv, messages, myId: req.user.id, otherName });
});

// إرسال رسالة (fetch من صفحة المحادثة)
router.post('/chat/:id/send', requireAuth, (req, res) => {
  const conv = db.prepare('SELECT * FROM conversations WHERE id = ?').get(req.params.id);
  if (!conv || (conv.buyer_id !== req.user.id && conv.seller_id !== req.user.id)) {
    return res.status(403).json({ error: 'غير مصرح' });
  }
  const body = (req.body.body || '').trim();
  if (!body) return res.status(400).json({ error: 'الرسالة فارغة' });

  db.prepare('INSERT INTO messages (conversation_id, sender_id, body) VALUES (?, ?, ?)').run(conv.id, req.user.id, body);
  res.json({ ok: true });
});

// جلب الرسائل الجديدة (يُستخدم للـ polling كل بضع ثوانٍ)
router.get('/chat/:id/messages.json', requireAuth, (req, res) => {
  const conv = db.prepare('SELECT * FROM conversations WHERE id = ?').get(req.params.id);
  if (!conv || (conv.buyer_id !== req.user.id && conv.seller_id !== req.user.id)) {
    return res.status(403).json({ error: 'غير مصرح' });
  }
  const messages = db.prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC').all(conv.id);
  res.json({ messages, myId: req.user.id });
});

module.exports = router;

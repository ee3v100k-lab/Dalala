const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

// تبديل حالة المفضلة (إضافة/إزالة) - يُستدعى عبر fetch من الواجهة
router.post('/ads/:id/favorite', requireAuth, (req, res) => {
  const adId = req.params.id;
  const existing = db.prepare('SELECT 1 FROM favorites WHERE user_id = ? AND ad_id = ?').get(req.user.id, adId);

  if (existing) {
    db.prepare('DELETE FROM favorites WHERE user_id = ? AND ad_id = ?').run(req.user.id, adId);
  } else {
    db.prepare('INSERT INTO favorites (user_id, ad_id) VALUES (?, ?)').run(req.user.id, adId);
  }

  const nowFav = !existing;
  if (req.headers.accept && req.headers.accept.includes('application/json')) {
    return res.json({ favorited: nowFav });
  }
  res.redirect('back');
});

router.get('/favorites', requireAuth, (req, res) => {
  const ads = db.prepare(`
    SELECT ads.*, categories.name AS category_name,
      (SELECT filename FROM ad_images WHERE ad_id = ads.id ORDER BY sort_order LIMIT 1) AS thumb
    FROM favorites
    JOIN ads ON ads.id = favorites.ad_id
    JOIN categories ON categories.id = ads.category_id
    WHERE favorites.user_id = ?
    ORDER BY favorites.created_at DESC
  `).all(req.user.id);

  res.render('favorites', { title: 'المفضلة | دلالة', ads });
});

module.exports = router;

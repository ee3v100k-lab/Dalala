(function () {
  const box = document.getElementById('chat-messages');
  const form = document.getElementById('chat-form');
  const input = document.getElementById('chat-input');
  if (!box || !form) return;

  const convId = box.dataset.convId;
  const myId = Number(box.dataset.myId);

  function scrollToBottom() {
    box.scrollTop = box.scrollHeight;
  }

  function renderMessages(messages) {
    box.innerHTML = '';
    messages.forEach(m => {
      const div = document.createElement('div');
      div.className = 'msg ' + (m.sender_id === myId ? 'mine' : 'theirs');
      div.textContent = m.body;
      box.appendChild(div);
    });
    scrollToBottom();
  }

  async function poll() {
    try {
      const res = await fetch(`/chat/${convId}/messages.json`);
      if (!res.ok) return;
      const data = await res.json();
      renderMessages(data.messages);
    } catch (err) {
      // تجاهل أخطاء الشبكة المؤقتة أثناء الاستطلاع
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = input.value.trim();
    if (!body) return;
    input.value = '';
    input.disabled = true;
    try {
      await fetch(`/chat/${convId}/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body }),
      });
      await poll();
    } finally {
      input.disabled = false;
      input.focus();
    }
  });

  scrollToBottom();
  setInterval(poll, 3000);
})();

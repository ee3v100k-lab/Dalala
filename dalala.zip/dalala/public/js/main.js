// تبديل المفضلة بدون إعادة تحميل الصفحة
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('.fav-btn');
  if (!btn) return;
  e.preventDefault();
  const adId = btn.dataset.adId;
  try {
    const res = await fetch(`/ads/${adId}/favorite`, {
      method: 'POST',
      headers: { Accept: 'application/json' },
    });
    if (res.status === 302 || res.redirected) {
      window.location.href = '/login';
      return;
    }
    const data = await res.json();
    btn.classList.toggle('active', data.favorited);
  } catch (err) {
    console.error('تعذر تحديث المفضلة', err);
  }
});

// معاينة الصور المختارة في نموذج نشر الإعلان
const imgInput = document.getElementById('images-input');
if (imgInput) {
  const preview = document.getElementById('images-preview');
  imgInput.addEventListener('change', () => {
    preview.innerHTML = '';
    const files = Array.from(imgInput.files).slice(0, 6);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = document.createElement('img');
        img.src = e.target.result;
        preview.appendChild(img);
      };
      reader.readAsDataURL(file);
    });
  });
}

// تبديل الصورة الرئيسية في معرض صفحة الإعلان
document.addEventListener('click', (e) => {
  const thumb = e.target.closest('.gallery-thumbs img');
  if (!thumb) return;
  const main = document.getElementById('gallery-main-img');
  if (main) main.src = thumb.src;
  document.querySelectorAll('.gallery-thumbs img').forEach(img => img.classList.remove('active'));
  thumb.classList.add('active');
});

// تعبئة الأقسام والولايات الأساسية - شغّلها مرة واحدة بأمر: npm run seed
const db = require('./index');

const categories = [
  { name: 'سيارات', icon_path: 'M3 13h1l2-5h12l2 5h1v5h-2v-2H5v2H3zM7 10l-1 3h12l-1-3z' },
  { name: 'عقارات', icon_path: 'M4 11 12 4l8 7v9h-6v-6h-4v6H4z' },
  { name: 'مواشي وحيوانات', icon_path: 'M12 3c-4 0-7 3-7 7 0 5 3 9 7 9s7-4 7-9c0-4-3-7-7-7zm-3 6a1 1 0 110 2 1 1 0 010-2zm6 0a1 1 0 110 2 1 1 0 010-2z' },
  { name: 'جوالات وإلكترونيات', icon_path: 'M8 2h8v20H8zM10 18h4' },
  { name: 'أثاث ومنزل', icon_path: 'M4 18v-6a2 2 0 012-2h12a2 2 0 012 2v6M4 18h16M6 12V8a2 2 0 012-2h8a2 2 0 012 2v4' },
  { name: 'وظائف', icon_path: 'M4 8h16v11H4zM9 8V6a2 2 0 012-2h2a2 2 0 012 2v2' },
  { name: 'أزياء', icon_path: 'M8 3l4 3 4-3 3 4-3 2v11H7V9L4 7z' },
  { name: 'خدمات', icon_path: 'M12 2l2 5 5 .7-3.6 3.6.9 5.2L12 14l-4.3 2.5.9-5.2L5 7.7 10 7z' },
  { name: 'رياضة وهوايات', icon_path: 'M12 2a10 10 0 100 20 10 10 0 000-20zm0 2v16M2 12h20' },
  { name: 'زراعة ومعدات', icon_path: 'M12 2s-6 5-6 11a6 6 0 0012 0c0-6-6-11-6-11z' },
];

const states = [
  'الخرطوم', 'أم درمان', 'بحري', 'بورتسودان', 'كسلا', 'ود مدني',
  'الأبيض', 'نيالا', 'عطبرة', 'الفاشر', 'الدمازين', 'كادوقلي',
  'القضارف', 'سنار', 'دنقلا', 'بربر', 'الجنينة', 'زالنجي',
];

const insertCat = db.prepare('INSERT OR IGNORE INTO categories (name, icon_path, sort_order) VALUES (?, ?, ?)');
categories.forEach((c, i) => insertCat.run(c.name, c.icon_path, i));

const insertState = db.prepare('INSERT OR IGNORE INTO states (name, sort_order) VALUES (?, ?)');
states.forEach((s, i) => insertState.run(s, i));

console.log(`تمت تعبئة ${categories.length} قسم و ${states.length} ولاية بنجاح.`);
